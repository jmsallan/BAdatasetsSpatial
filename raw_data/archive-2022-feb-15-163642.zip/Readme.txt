README.TXT

Servei Sistemes d'Informació Territorial.

ZIP generat dinàmicament a 15/02/2022 16:36:42
per una pàgina ASP.NET, a la màquina anomenada 'GENBUAGS'.
Server type: Microsoft-IIS/7.5

Per a més informació, contactar amb sistemes.informacio.territorial@terrassa.cat

Dades transformades de ED50 a ETRS89 mitjançant la malla NTv2 de transformació calculada per l'Institut Cartogràfic de Catalunya.