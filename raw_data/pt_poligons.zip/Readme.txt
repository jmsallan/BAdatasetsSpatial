README.TXT

Servei Sistemes d'Informació Territorial.

ZIP generat dinàmicament a 06/02/2022 4:00:19
per una pàgina ASP.NET, a la màquina anomenada 'GENBUAGS'.
Server type: Microsoft-IIS/7.5

Per a més informació, contactar amb sistemes.informacio.territorial@terrassa.cat
