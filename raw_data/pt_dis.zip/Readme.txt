README.TXT

Servei Sistemes d'Informació Territorial.

ZIP generat dinàmicament a 05/10/2021 18:35:43
per una pàgina ASP.NET, a la màquina anomenada 'GENBUAGS'.
Server type: Microsoft-IIS/7.5

Per a més informació, contactar amb sistemes.informacio.territorial@terrassa.cat
